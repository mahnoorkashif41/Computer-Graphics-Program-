import turtle
import time

screen = turtle.Screen()

# Background colors
colors = ["yellow", "lightblue", "pink", "lightgreen", "orange"]

t = turtle.Turtle()
t.speed(5)
t.pensize(3)

for bg in colors:

    screen.bgcolor(bg)

    t.clear()

    # Pencil body
    t.penup()
    t.goto(-100, 0)
    t.pendown()

    t.forward(200)
    t.left(90)
    t.forward(40)
    t.left(90)
    t.forward(200)
    t.left(90)
    t.forward(40)

    # Pencil tip
    t.penup()
    t.goto(100, 0)
    t.pendown()

    t.goto(140, 20)
    t.goto(100, 40)

    # Lead
    t.goto(150, 20)
    t.goto(140, 20)

    t.setheading(0)

    time.sleep(1)

turtle.done()