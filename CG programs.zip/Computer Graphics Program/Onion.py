import turtle
import math

t = turtle.Turtle()
t.speed(0)

# Function to draw ellipse
def draw_ellipse(a, b):
    t.penup()

    for angle in range(361):
        x = a * math.cos(math.radians(angle))
        y = b * math.sin(math.radians(angle))

        if angle == 0:
            t.goto(x, y)
            t.pendown()
        else:
            t.goto(x, y)

# Onion drawing
x = 0
y = 0

m = 5
z = 80

for i in range(13):
    t.penup()
    t.goto(x, y)
    t.pendown()

    draw_ellipse(m, z)

    m += 9
    z -= 1

turtle.done()