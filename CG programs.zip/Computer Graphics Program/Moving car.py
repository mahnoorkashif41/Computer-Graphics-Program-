import pygame

pygame.init()

# Screen
screen = pygame.display.set_mode((800, 400))
pygame.display.set_caption("Moving Car")

# Colors
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
BLACK = (0, 0, 0)

# Car position
x = 0
y = 250

clock = pygame.time.Clock()

running = True
while running:

    screen.fill(WHITE)

    # Car body
    pygame.draw.rect(screen, BLUE, (x, y, 120, 50))

    # Car top
    pygame.draw.rect(screen, BLUE, (x + 20, y - 30, 80, 30))

    # Wheels
    pygame.draw.circle(screen, BLACK, (x + 25, y + 55), 15)
    pygame.draw.circle(screen, BLACK, (x + 95, y + 55), 15)

    # Move car
    x += 5

    # Restart from left
    if x > 800:
        x = -120

    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            running = False

    pygame.display.update()
    clock.tick(30)

pygame.quit()