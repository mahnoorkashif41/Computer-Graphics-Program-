import turtle

t = turtle.Turtle()
t.speed(5)

t.circle(100, 90)  # radius 100, arc angle 90°

turtle.done()