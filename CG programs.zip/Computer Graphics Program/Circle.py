import turtle
# Create screen
screen = turtle.Screen()
# Create turtle
pen = turtle.Turtle()
# Draw a circle
pen.circle(100)
# Keep window open
screen.mainloop()