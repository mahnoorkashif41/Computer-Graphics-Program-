import turtle
screen = turtle.Screen()

pen = turtle.Turtle()
# Speed up drawing

pen.speed(10)
# Draw ellipse using stretched circle
for _ in range(2):
    pen.circle(100, 90)   # arc 1
    pen.circle(50, 90)    # arc 2 (smaller radius gives ellipse shape)

screen.mainloop()