import turtle

t = turtle.Turtle()
t.speed(5)
# Draw a bar (rectangle)
t.forward(200)   # bottom side
t.left(90)
t.forward(100)   # right side
t.left(90)
t.forward(200)   # top side
t.left(90)
t.forward(100)   # left side

turtle.done()