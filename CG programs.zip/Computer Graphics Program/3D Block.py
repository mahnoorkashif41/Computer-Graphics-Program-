import turtle

t = turtle.Turtle()
t.speed(5)

# Front face
t.fillcolor("blue")
t.begin_fill()

for _ in range(2):
    t.forward(150)
    t.left(90)
    t.forward(100)
    t.left(90)

t.end_fill()

# Top face (fake 3D effect)
t.fillcolor("lightblue")
t.begin_fill()

t.left(30)
t.forward(150)
t.right(30)
t.forward(60)
t.right(150)
t.forward(150)
t.right(30)
t.forward(60)

t.end_fill()

# Side face
t.fillcolor("darkblue")
t.begin_fill()

t.right(180)
t.forward(100)
t.left(120)
t.forward(60)
t.left(60)
t.forward(100)
t.left(120)
t.forward(60)

t.end_fill()

turtle.done()