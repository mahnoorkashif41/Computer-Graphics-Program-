import turtle
# Create screen
screen = turtle.Screen()
# Create turtle
pen = turtle.Turtle()
# Draw a line
pen.forward(200)
# Keep window open
screen.mainloop()